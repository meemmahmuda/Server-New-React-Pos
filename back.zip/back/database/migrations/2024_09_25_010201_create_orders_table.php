<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();  // Primary key
            $table->unsignedBigInteger('product_id');  // Match this to 'products.id'
            $table->unsignedBigInteger('supplier_id');  // Match this to 'suppliers.id'
            $table->integer('quantity');
            $table->integer('purchase_price');
            $table->integer('total_price');
            $table->integer('amount_given')->nullable(); // Column for amount given
            $table->integer('amount_return')->nullable(); // Column for amount returned
            $table->timestamps();

            // Foreign keys
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
            $table->foreign('supplier_id')->references('id')->on('suppliers')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
